#ifndef STR_AUX_H
#define STR_AUX_H

#include <string>
#include <sstream>

using std::string;
using std::stringstream;

string itoa(int, string);
string itos(int);
string reverse(string);

#endif
